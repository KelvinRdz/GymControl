package com.gymcontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
